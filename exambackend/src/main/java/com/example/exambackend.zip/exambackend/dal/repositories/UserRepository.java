package com.example.exambackend.dal.repositories;

import com.example.exambackend.models.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Integer> {
}
