package com.example.exambackend.dal.repositories;

import com.example.exambackend.models.Answer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnswerRepository extends JpaRepository<Answer, Integer> {
}
