package com.example.exambackend.dal.daos;

public class UserDao {
}
