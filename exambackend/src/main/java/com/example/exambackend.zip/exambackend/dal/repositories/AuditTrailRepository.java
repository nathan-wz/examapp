package com.example.exambackend.dal.repositories;

import com.example.exambackend.models.AuditTrail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditTrailRepository extends JpaRepository<AuditTrail, Integer> {
}
