package com.example.exambackend.dal.repositories;

import com.example.exambackend.models.Attempt;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AttemptRepository extends JpaRepository<Attempt, Integer> {
}
